from ui_logic.ui_core import get_page_manifest, dispatch_page

__all__ = ["get_page_manifest", "dispatch_page"]
