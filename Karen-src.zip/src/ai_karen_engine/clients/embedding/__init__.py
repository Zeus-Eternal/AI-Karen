from ai_karen_engine.clients.embedding.embedding_client import get_embedding

__all__ = ["get_embedding"]
