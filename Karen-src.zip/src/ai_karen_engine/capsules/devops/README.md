# DevOps Capsule

This capsule runs deployment and infrastructure tasks for the Kari Hydra-Ops mesh. It enforces role-based access control and secure execution when performing DevOps operations.

