"""Intent detection wrapper for Kari."""

from ai_karen_engine.core.intent_engine import IntentEngine

__all__ = ["IntentEngine"]
