"""Compatibility re-exports for the plugin router."""

from ai_karen_engine.plugins.router import PluginRouter, PluginRecord

__all__ = ["PluginRouter", "PluginRecord"]
