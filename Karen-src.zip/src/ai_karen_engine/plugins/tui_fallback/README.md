# TUI Fallback Plugin

Starts the interactive terminal UI when no graphical interface is available.

