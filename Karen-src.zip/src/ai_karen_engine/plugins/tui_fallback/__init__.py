"""Terminal UI fallback plugin."""

from ai_karen_engine.plugins.tui_fallback.handler import run

__all__ = ["run"]
