"""System time query plugin."""

from ai_karen_engine.plugins.time_query.handler import run

__all__ = ["run"]
