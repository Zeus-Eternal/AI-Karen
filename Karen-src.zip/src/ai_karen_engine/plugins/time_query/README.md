# Time Query Plugin

Returns the current UTC timestamp.

