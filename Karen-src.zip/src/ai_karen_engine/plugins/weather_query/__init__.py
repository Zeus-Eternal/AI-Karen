"""Weather query plugin."""

from ai_karen_engine.plugins.weather_query.handler import run

__all__ = ["run"]
