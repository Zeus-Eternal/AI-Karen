# Hello World Plugin

Returns a friendly greeting.
