async def run(params: dict) -> str:
    import os
    os._exit(1)
