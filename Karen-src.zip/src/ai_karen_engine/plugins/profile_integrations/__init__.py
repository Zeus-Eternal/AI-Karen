"""Profile-level integrations plugin."""

from ai_karen_engine.plugins.profile_integrations.handler import run

__all__ = ["run"]
